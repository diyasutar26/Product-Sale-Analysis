```python
import pandas as pd
import numpy as np
import seaborn as sms
import matplotlib.pyplot as plt
```


```python
import os
```


```python
#import data
os.listdir (r"D:\Downloads\Python_Diwali_Sales_Analysis\Python_Diwali_Sales_Analysis")
```




    ['Diwali Sales Data.csv',
     'Diwali_Sales_Analysis.ipynb',
     'DIWALI_SALES_PROJECT.ipynb']




```python
sale_data = pd.read_csv (r"D:\Downloads\Python_Diwali_Sales_Analysis\Python_Diwali_Sales_Analysis/Diwali Sales Data.csv" , encoding = "unicode_escape")
```


```python
sale_data.shape
```




    (11251, 15)




```python
sale_data.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>User_ID</th>
      <th>Cust_name</th>
      <th>Product_ID</th>
      <th>Gender</th>
      <th>Age Group</th>
      <th>Age</th>
      <th>Marital_Status</th>
      <th>State</th>
      <th>Zone</th>
      <th>Occupation</th>
      <th>Product_Category</th>
      <th>Orders</th>
      <th>Amount</th>
      <th>Status</th>
      <th>unnamed1</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1002903</td>
      <td>Sanskriti</td>
      <td>P00125942</td>
      <td>F</td>
      <td>26-35</td>
      <td>28</td>
      <td>0</td>
      <td>Maharashtra</td>
      <td>Western</td>
      <td>Healthcare</td>
      <td>Auto</td>
      <td>1</td>
      <td>23952.00</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1000732</td>
      <td>Kartik</td>
      <td>P00110942</td>
      <td>F</td>
      <td>26-35</td>
      <td>35</td>
      <td>1</td>
      <td>Andhra Pradesh</td>
      <td>Southern</td>
      <td>Govt</td>
      <td>Auto</td>
      <td>3</td>
      <td>23934.00</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1001990</td>
      <td>Bindu</td>
      <td>P00118542</td>
      <td>F</td>
      <td>26-35</td>
      <td>35</td>
      <td>1</td>
      <td>Uttar Pradesh</td>
      <td>Central</td>
      <td>Automobile</td>
      <td>Auto</td>
      <td>3</td>
      <td>23924.00</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1001425</td>
      <td>Sudevi</td>
      <td>P00237842</td>
      <td>M</td>
      <td>0-17</td>
      <td>16</td>
      <td>0</td>
      <td>Karnataka</td>
      <td>Southern</td>
      <td>Construction</td>
      <td>Auto</td>
      <td>2</td>
      <td>23912.00</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1000588</td>
      <td>Joni</td>
      <td>P00057942</td>
      <td>M</td>
      <td>26-35</td>
      <td>28</td>
      <td>1</td>
      <td>Gujarat</td>
      <td>Western</td>
      <td>Food Processing</td>
      <td>Auto</td>
      <td>2</td>
      <td>23877.00</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1000588</td>
      <td>Joni</td>
      <td>P00057942</td>
      <td>M</td>
      <td>26-35</td>
      <td>28</td>
      <td>1</td>
      <td>Himachal Pradesh</td>
      <td>Northern</td>
      <td>Food Processing</td>
      <td>Auto</td>
      <td>1</td>
      <td>23877.00</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>6</th>
      <td>1001132</td>
      <td>Balk</td>
      <td>P00018042</td>
      <td>F</td>
      <td>18-25</td>
      <td>25</td>
      <td>1</td>
      <td>Uttar Pradesh</td>
      <td>Central</td>
      <td>Lawyer</td>
      <td>Auto</td>
      <td>4</td>
      <td>23841.00</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>7</th>
      <td>1002092</td>
      <td>Shivangi</td>
      <td>P00273442</td>
      <td>F</td>
      <td>55+</td>
      <td>61</td>
      <td>0</td>
      <td>Maharashtra</td>
      <td>Western</td>
      <td>IT Sector</td>
      <td>Auto</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>8</th>
      <td>1003224</td>
      <td>Kushal</td>
      <td>P00205642</td>
      <td>M</td>
      <td>26-35</td>
      <td>35</td>
      <td>0</td>
      <td>Uttar Pradesh</td>
      <td>Central</td>
      <td>Govt</td>
      <td>Auto</td>
      <td>2</td>
      <td>23809.00</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>9</th>
      <td>1003650</td>
      <td>Ginny</td>
      <td>P00031142</td>
      <td>F</td>
      <td>26-35</td>
      <td>26</td>
      <td>1</td>
      <td>Andhra Pradesh</td>
      <td>Southern</td>
      <td>Media</td>
      <td>Auto</td>
      <td>4</td>
      <td>23799.99</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
sale_data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 11251 entries, 0 to 11250
    Data columns (total 15 columns):
     #   Column            Non-Null Count  Dtype  
    ---  ------            --------------  -----  
     0   User_ID           11251 non-null  int64  
     1   Cust_name         11251 non-null  object 
     2   Product_ID        11251 non-null  object 
     3   Gender            11251 non-null  object 
     4   Age Group         11251 non-null  object 
     5   Age               11251 non-null  int64  
     6   Marital_Status    11251 non-null  int64  
     7   State             11251 non-null  object 
     8   Zone              11251 non-null  object 
     9   Occupation        11251 non-null  object 
     10  Product_Category  11251 non-null  object 
     11  Orders            11251 non-null  int64  
     12  Amount            11239 non-null  float64
     13  Status            0 non-null      float64
     14  unnamed1          0 non-null      float64
    dtypes: float64(3), int64(4), object(8)
    memory usage: 1.3+ MB
    


```python
#drop blank columns
sale_data.drop(['Status', 'unnamed1'], axis=1 , inplace=True)
```


```python
sale_data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 11251 entries, 0 to 11250
    Data columns (total 13 columns):
     #   Column            Non-Null Count  Dtype  
    ---  ------            --------------  -----  
     0   User_ID           11251 non-null  int64  
     1   Cust_name         11251 non-null  object 
     2   Product_ID        11251 non-null  object 
     3   Gender            11251 non-null  object 
     4   Age Group         11251 non-null  object 
     5   Age               11251 non-null  int64  
     6   Marital_Status    11251 non-null  int64  
     7   State             11251 non-null  object 
     8   Zone              11251 non-null  object 
     9   Occupation        11251 non-null  object 
     10  Product_Category  11251 non-null  object 
     11  Orders            11251 non-null  int64  
     12  Amount            11239 non-null  float64
    dtypes: float64(1), int64(4), object(8)
    memory usage: 1.1+ MB
    


```python
#checking null values
pd.isnull(sale_data)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>User_ID</th>
      <th>Cust_name</th>
      <th>Product_ID</th>
      <th>Gender</th>
      <th>Age Group</th>
      <th>Age</th>
      <th>Marital_Status</th>
      <th>State</th>
      <th>Zone</th>
      <th>Occupation</th>
      <th>Product_Category</th>
      <th>Orders</th>
      <th>Amount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>11246</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>11247</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>11248</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>11249</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>11250</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>11251 rows × 13 columns</p>
</div>




```python
pd.isnull(sale_data).sum()
```




    User_ID              0
    Cust_name            0
    Product_ID           0
    Gender               0
    Age Group            0
    Age                  0
    Marital_Status       0
    State                0
    Zone                 0
    Occupation           0
    Product_Category     0
    Orders               0
    Amount              12
    dtype: int64




```python
#drop null values
sale_data.dropna(inplace= True)
```


```python
sale_data.shape
```




    (11239, 13)




```python
#change dtype
sale_data['Amount'] = sale_data ['Amount'].astype('int')
```


```python
sale_data['Amount'].dtypes
```




    dtype('int32')



# EDA

## Gender


```python
sale_data.columns
```




    Index(['User_ID', 'Cust_name', 'Product_ID', 'Gender', 'Age Group', 'Age',
           'Marital_Status', 'State', 'Zone', 'Occupation', 'Product_Category',
           'Orders', 'Amount'],
          dtype='object')




```python
ax = sms.countplot(x= 'Gender' , data = sale_data)
```


    
![png](output_18_0.png)
    



```python
ax = sms.countplot(x= 'Gender' , data = sale_data)

for bars in ax.containers:
    ax.bar_label(bars)
```


    
![png](output_19_0.png)
    



```python
sale_data.groupby(['Gender'], as_index = False)['Amount'].sum().sort_values(by= 'Amount', ascending = False)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Gender</th>
      <th>Amount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>F</td>
      <td>74335853</td>
    </tr>
    <tr>
      <th>1</th>
      <td>M</td>
      <td>31913276</td>
    </tr>
  </tbody>
</table>
</div>




```python
sale_gender = sale_data.groupby(['Gender'], as_index = False)['Amount'].sum().sort_values(by= 'Amount', ascending = False)
```

#### From the above plots, we can conclude that the number of female buyers is greater than male

## Age


```python
age_data = sms.countplot(x= 'Age Group' , data = sale_data , hue= 'Gender')


for bars in ax.containers:
    ax.bar_label(bars)
```


    
![png](output_24_0.png)
    



```python
sale_data.groupby(['Age Group'], as_index = False)['Amount'].sum().sort_values(by= 'Amount', ascending = False)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age Group</th>
      <th>Amount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2</th>
      <td>26-35</td>
      <td>42613442</td>
    </tr>
    <tr>
      <th>3</th>
      <td>36-45</td>
      <td>22144994</td>
    </tr>
    <tr>
      <th>1</th>
      <td>18-25</td>
      <td>17240732</td>
    </tr>
    <tr>
      <th>4</th>
      <td>46-50</td>
      <td>9207844</td>
    </tr>
    <tr>
      <th>5</th>
      <td>51-55</td>
      <td>8261477</td>
    </tr>
    <tr>
      <th>6</th>
      <td>55+</td>
      <td>4080987</td>
    </tr>
    <tr>
      <th>0</th>
      <td>0-17</td>
      <td>2699653</td>
    </tr>
  </tbody>
</table>
</div>




```python
sale_age = sale_data.groupby(['Age Group'], as_index = False)['Amount'].sum().sort_values(by= 'Amount', ascending = False)
```

#### From the above plot, we can conclude that the maximum number of buyers belong to the age group between 26-35 female.

## State


```python
#Orders from top 5 states
sale_state = sale_data.groupby(['State'], as_index = False)['Orders'].sum().sort_values(by= 'Orders', ascending = False).head(10)

sms.set(rc={'figure.figsize' : (15,5)})
sms.barplot(data = sale_state , x= 'State' , y= 'Orders')
```




    <Axes: xlabel='State', ylabel='Orders'>




    
![png](output_29_1.png)
    



```python
#Total Amount from top 5 states
sale_state = sale_data.groupby(['State'], as_index = False)['Amount'].sum().sort_values(by= 'Amount', ascending = False).head(10)

sms.set(rc={'figure.figsize' : (15,5)})
sms.barplot(data = sale_state , x= 'State' , y= 'Amount')
```




    <Axes: xlabel='State', ylabel='Amount'>




    
![png](output_30_1.png)
    


#### From the above plot, we can say that the maximum sale has been done in Uttar Pradesh. Also, we can notice that karela has made more orders compare to haryana and gujrat but amount spent is less.

## Marital Status


```python

```


```python
ms = sms.countplot(x= 'Marital_Status' , data = sale_data)

sms.set(rc={'figure.figsize' : (6,5)})

for bars in ax.containers:
    ax.bar_label(bars)
```


    
![png](output_34_0.png)
    



```python
sale_ms = sale_data.groupby(['Marital_Status'], as_index = False)['Amount'].sum().sort_values(by= 'Amount', ascending = False)

sms.set(rc={'figure.figsize' : (15,5)})
sms.barplot(data = sale_ms , x= 'Marital_Status' , y= 'Amount')
```




    <Axes: xlabel='Marital_Status', ylabel='Amount'>




    
![png](output_35_1.png)
    


#### Married People has the highest purchasing power  

## Occupation


```python
ms = sms.countplot(x= 'Occupation' , data = sale_data)

sms.set(rc={'figure.figsize' : (25,5)})

for bars in ms.containers:
    ms.bar_label(bars)
```


    
![png](output_38_0.png)
    



```python
sale_ms = sale_data.groupby(['Occupation'], as_index = False)['Amount'].sum().sort_values(by= 'Amount', ascending = False)

sms.set(rc={'figure.figsize' : (25,5)})
sms.barplot(data = sale_ms , x= 'Occupation' , y= 'Amount')
```




    <Axes: xlabel='Occupation', ylabel='Amount'>




    
![png](output_39_1.png)
    


#### From the above graph we can notice that the most of the buyers are working in IT, Healthcare and Aviation. 

## Product Category 


```python
ms = sms.countplot(x= 'Product_Category' , data = sale_data)

sms.set(rc={'figure.figsize' : (25,5)})

for bars in ms.containers:
    ms.bar_label(bars)
```


    
![png](output_42_0.png)
    



```python
sale_ms = sale_data.groupby(['Product_Category'], as_index = False)['Amount'].sum().sort_values(by= 'Amount', ascending = False).head(10)

sms.set(rc={'figure.figsize' : (25,5)})
sms.barplot(data = sale_ms , x= 'Product_Category' , y= 'Amount')
```




    <Axes: xlabel='Product_Category', ylabel='Amount'>




    
![png](output_43_1.png)
    


#### From the above plot we can conclude that the maximum sold product is Food  

# Conclusion

#### " It is possible that married women aged 26-35 from UP, Maharashtra, and Karnataka working in IT, Healthcare, and Aviation may prioritize purchasing food products followed by clothing."


```python

```
